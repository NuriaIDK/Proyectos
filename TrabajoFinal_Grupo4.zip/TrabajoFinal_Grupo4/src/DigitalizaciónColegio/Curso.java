package DigitalizaciónColegio;

public class Curso {
}
